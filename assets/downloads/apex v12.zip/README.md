# APEX // THREAT LAB

An advanced-looking AI analyst terminal focused on **malware theory and malware concepts** — taxonomy, propagation, persistence, evasion, C2, rootkits, ransomware, APTs, reverse engineering, memory forensics, and the defensive countermeasures behind each.

The AI is oriented as an analyst/teacher: it explains concepts and mechanisms, anchors them to frameworks (MITRE ATT&CK, Cyber Kill Chain, Diamond Model) and real families as case studies, and pairs them with detection/mitigation.

## Contents

```
perchance/           → the version that runs on perchance.org
  main.pjs
  index.html
standalone/          → a fully self-contained version that runs anywhere
  index.html
  apex-creator.html  → the editable edition — same terminal, with an in-page ✎ CREATOR panel
assets/
  logo.jpg           → the emblem used by both versions
apex-studio.html     → APEX // STUDIO — a general-purpose AI assistant + AI page BUILDER (chat + live-preview builder, standalone)
README.md
```

---

## Option A — Run on Perchance (uses Perchance's built-in AI, no key needed)

1. Go to https://perchance.org and create a new generator.
2. Paste `perchance/main.pjs` into the **pjs** tab, and `perchance/index.html` into the **html** tab.
3. Done — the `ai-text-plugin` import resolves automatically and the AI just works.
4. (Optional) Replace the logo URL in `index.html` with your own image if you prefer.

## Option B — Run the standalone version (works offline, no Perchance)

The AI endpoint is **not** built in, so you plug in your own OpenAI-compatible API.

1. Open `standalone/index.html` in any modern browser (just double-click it — no server needed).
2. Click the **⚙** button in the header.
3. Enter:
   - **API BASE URL** — e.g. `https://api.openai.com/v1`, or Groq, OpenRouter, Together, or a local server like `http://localhost:11434/v1` (Ollama) or LM Studio.
   - **MODEL** — e.g. `gpt-4o-mini`, `llama-3.3-70b-versatile`, `deepseek-r1`, etc.
   - **API KEY** — your key. It is stored only in your browser's localStorage and never leaves it.
4. Save, then transmit.

You can **send messages at any time** — even before configuring an endpoint. If the endpoint rejects the request (no key, wrong URL), the terminal shows the exact error plus a reminder to open ⚙ SETTINGS. A local server like Ollama needs no API key at all.

## Option C — APEX Creator (the editable edition)

`standalone/apex-creator.html` is the same terminal but with an **in-page editor**: click the **✎** button in the header and the CREATOR panel slides in. You can edit everything about the page and it applies live:
- **System prompt** — redefine exactly what kind of AI this is ("your type of AI")
- **Analyst tones** — the three voices (ANALYST / MENTOR / FIELD OPS)
- **Persona presets** — one-click presets: THREAT ANALYST, CYBER MENTOR, NOIR NARRATOR
- **Quick topics** (the probe chips), **follow-up buttons**, **threat feed** ticker
- **Knowledge modules** and their injected knowledge briefs
- **Boot log** lines, **title** and **subtitle**
- **SAVE & APPLY** keeps your config in the browser (persists across reloads), **EXPORT .JSON** / **IMPORT** let you share or back up your configuration, **RESET DEFAULTS** restores the originals

Your **chat history is saved** to the browser between sessions (including the auto-summary), so reloading the page restores the conversation.

## Option D — APEX Studio (a different app: build pages with AI)

`apex-studio.html` is a **separate standalone app** — a general-purpose AI assistant (not malware-focused) with two tabs:

- **◈ CHAT** — talk to the AI about anything: coding help, explanations, file drop-in for review, voice input, syntax-highlighted code answers, follow-ups, transcript export.
- **🛠 BUILDER** — describe a page in plain words ("a pomodoro timer with a circular ring", "a landing page for a cyberpunk game", "a typing speed test with particle background") → the AI writes the whole page → it renders in a **live preview** → type refinements ("make it green", "add a score system", "make it responsive") and press **ITERATE** → the full page updates → revision pills let you jump back → **EXPORT** downloads your finished page as a standalone `.html`, or **OPEN** shows it in a new tab.

Plug any OpenAI-compatible endpoint via ⚙ (or use a local Ollama/LM Studio server with no key). Your chat log and your current build (including all revisions) auto-save in the browser.

---

## Features

- **Cinematic three-phase boot (v9 intro engine)** — Phase 1 is a `SECURE IDENTIFICATION REQUIRED` operator-authentication gate over the moonlit sakura scene (OPERATOR/CLEARANCE/ACCESS rows, sweeping biometric scan bar, gradient-corner glass card, blinking authenticate prompt); any key or tap grants access with a synthesized boot chord. Phase 2 is a **full cinematic intro canvas**: data-glyph rain + perspective floor grid → a particle swarm flies in with motion trails and crystallizes into a glowing hexagon + hexagram emblem with a 桜 core, rotating radar dial and sweep, then target brackets lock on and a white flash pops (any key/click skips). Phase 3 runs the classic sequence: procedurally-grown anime cherry-blossom tree, glitch-per-character typewriter title `ＡＰＥＸ // ＴＨＲＥＡＴ ＬＡＢ`, red `桜` hanko stamp, phase-tagged boot log (`[ＫＥＲＮＥＬ]`, `[桜花]`, `[防衛]`, `[ＧＵＡＲＤ]`, …) with animated progress bars and `✓ OK`, then `ACCESS GRANTED — SYSTEM READY`
- **v9 "10x" visual pass** — animated gradient-flow title, glassmorphism panels with gradient top-lights, blueprint grid + scanline ambience, hover sweep-shine on chips/buttons, staggered message entrance animations, pulsing avatar rings, shimmering context bar, glowing inputs, upgraded auth card, dial-ring radar boot UI, and a re-styled boot log terminal
- **Sakura UI theme** — default `sakura` accent (soft pinks) recolors the entire terminal; a drifting **petal overlay** with a corner sakura branch floats over the whole UI
- **Multi-panel terminal workstation**: live telemetry (CPU/MEM/NET), flickering guard-status gauge, mode badge, **THREAT FEED** ticker, corner-frame CRT styling, drifting background **particle field**
- **Voice input** 🎙 — press the mic button (or `/voice`) and speak; your speech is transcribed into the transmit field and sent. Gracefully disables where SpeechRecognition isn't available
- **File analysis** 📎 — drag a file onto the chat or use the attach button; the terminal reads text files and has the analyst triage the specimen (structure, notable strings, suspicious markers, defensive triage), or explains what the file type does when binary
- **Multi-session manager** — sidebar SESSIONS panel (+ `/new`, `/load <ID>`, `/del <ID>`, `/sessions`) keeps multiple saved conversations; each session persists its own transcript and auto-summary; switch with one click
- **Analyst tone personas** — sidebar dropdown or `/tone <analyst|mentor|fieldops>` changes the AI's voice (clinical analyst / educator / tactical field operator); shown in the status bar and welcome banner
- **Markdown v2** — syntax-highlighted code blocks with **language headers, line numbers and one-click copy** (JS/Python/Shell/PowerShell/YAML/JSON/C/C++/SQL…), plus tables, headers, lists and blockquotes. Copying is **clean**: the per-block `⧉ COPY` and the `[ COPY ALL ]` button extract pure code/text — no line numbers, real newlines — so pasted code never comes out jumbled or sideways
- **Analysis badges** — every AI answer gets technique tags (◆ INJECTION, ◆ PERSISTENCE, ◆ RANSOMWARE…) plus a TRUST score, generated from the reply's content
- **Long-output engine** — when a response gets cut off mid-generation (per-request token cap), the terminal **automatically continues** it exactly where it stopped and merges it into the same message — up to ~100KB / 30 passes, each verified against truncation heuristics (unclosed code fences, `length`/`max_tokens` stop reasons, mid-line cuts). A **[ CONTINUE ]** button on every answer resumes it manually. Long code outputs no longer stop around 5KB.
- **Strict-focus discipline** — every request carries a focus protocol (answer exactly the one thing asked, one artifact, no 'bonus'/'also here is' extras, restart cleanly instead of mixing code) and a **context budget** (old giant messages are truncated before being sent to the model, so earlier programs can't leak into new answers). Continuations are locked to the **original request text** and forbid re-opening fences or re-declaring classes, keeping long code a single continuous program.
- **Thinking-phase indicator** — while generating, the typing dots cycle through analyst progress labels (`CROSS-REFERENCING MITRE ATT&CK`, `TRACING BEHAVIOR GRAPHS`, …)
- **Accent theme system** — 6 colorways (sakura, green, cyan, amber, magenta, red) via sidebar dots or `/theme <name>`; persisted between sessions
- **Collapsible sidebar** — ◧/◨ button enters "focus mode"; on mobile the sidebar becomes a **slide-in drawer** (☰ button)
- **Command palette** — type `/` in the transmit field for `/clear`, `/export`, `/exportjson`, `/deep`, `/balanced`, `/concise`, `/focus <module>`, `/theme <name>`, `/tone`, `/sessions`, `/new`, `/load`, `/del`, `/voice`, `/matrix`, `/ascii`, `/stats`, `/search <term>`, `/help` (keyboard-navigable, Enter/Tab to run)
- **Easter eggs** — `/matrix` rains katakana down the screen in your accent color; `/ascii` prints the APEX banner
- **Session statistics** — `/stats` prints a live SESSION LOG bubble (messages, tokens, avg reply time, tone, sessions on file); the sidebar SESSION LOG panel updates in real time
- **Transcript search** — `/search term` highlights matches across all messages; Escape clears
- **Knowledge modules** (sidebar): toggle the AI's focus — Taxonomy, Persistence & Evasion, Detection & Defenses, Ransomware, APTs, Memory Forensics, Reverse Engineering; each module injects a grounded knowledge brief into the prompt
- **Session tools**: one-click clear (with confirm), transcript **export** as `.txt` or `.json`
- Streaming AI responses (typing dots + thinking phases, blinking cursor, **STOP**, response-latency readout, sound blips with a 🔊/🔇 toggle), **live input char counter**, avatar chips on every message (OP / A), `⚡ RANDOM PROBE` chip
- **DEEP / BALANCED / CONCISE** analysis modes, markdown rendering including tables
- Time-of-day operator greeting in the welcome banner; classic terminal **status bar** (online state, mode, tone, session, model, UTC clock), live session ID, uptime, event ticker, context/token usage bar
- **Copy / regenerate / smart follow-ups** (deeper, defensive angle, real-world cases, simpler) on each answer; up-arrow recalls previous queries
- Chat history persists in the browser (localStorage) — reloads restore the conversation
- Fully responsive: sidebar flattens to a control strip on small screens

## Commands (type `/` in the transmit field)

| Command | Effect |
|---|---|
| `/clear` | wipe the session & memory |
| `/export` · `/exportjson` | download transcript as `.txt` / `.json` |
| `/deep` · `/balanced` · `/concise` | switch analysis mode |
| `/focus <module>` | toggle a knowledge module (taxonomy, persist, detect, ransom, apt, forensics, re) |
| `/theme <name>` | switch accent color (sakura, green, cyan, amber, magenta, red) |
| `/tone <name>` | switch analyst tone (analyst, mentor, fieldops) |
| `/sessions` | list saved sessions |
| `/new` | start a new session |
| `/load <ID>` | open a saved session |
| `/del <ID>` | delete a saved session |
| `/voice` | toggle voice input |
| `/matrix` | toggle the katakana rain overlay |
| `/ascii` | print the APEX banner |
| `/stats` | show live session statistics |
| `/search <term>` | highlight matches in the transcript (Esc clears) |
| `/help` | show the command list in chat |

Navigate the palette with ↑/↓, run with Enter or Tab.

## Notes

- Educational / defensive framing: the assistant explains malware theory and concepts and points to detection and mitigation — it won't produce weaponized payloads or exploit code.
- The banner in `index.html` references the emblem via its hosted URL (works in both versions).
